# ScienceAlert Updated

This is a minor updated version of the Kerbal Space Program mod ScienceAlert (see original here: https://github.com/DennyTX/ScienceAlert) to fix a few bugs.
